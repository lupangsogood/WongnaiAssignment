package com.candidate.android.dev.wongnai_assignment.Data.model.CoinModel

data class Link(
    var name: String? = null,
    var type: String? = null,
    var url: String? = null
)