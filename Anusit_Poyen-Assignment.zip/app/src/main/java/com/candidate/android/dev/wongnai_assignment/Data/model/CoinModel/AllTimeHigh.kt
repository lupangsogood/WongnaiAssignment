package com.candidate.android.dev.wongnai_assignment.Data.model.CoinModel

data class AllTimeHigh(
    var price: String? = null,
    var timestamp: Long? = null
)