package com.candidate.android.dev.wongnai_assignment.Data.model.CoinModel

data class Data(
    var base: Base? = null,
    var coins: ArrayList<CoinX>? = null,
    var stats: Stats? = null
)