package com.candidate.android.dev.wongnai_assignment.Extension

fun Any.simpleName(): String = this::class.java.simpleName