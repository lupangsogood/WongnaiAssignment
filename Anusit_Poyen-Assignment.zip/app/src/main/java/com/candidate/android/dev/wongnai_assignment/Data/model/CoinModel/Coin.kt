package com.candidate.android.dev.wongnai_assignment.Data.model.CoinModel

data class Coin(
    var data: Data? = null,
    var status: String? = null
)