package com.candidate.android.dev.wongnai_assignment.Data.model.CoinModel

data class Base(
    var sign: String? = null,
    var symbol: String? = null
)